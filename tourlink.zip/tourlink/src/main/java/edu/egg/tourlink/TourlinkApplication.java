package edu.egg.tourlink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourlinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourlinkApplication.class, args);
	}

}
