package edu.egg.tourlink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourlinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
